# Shopping List Application

This application consists of a create, read and deletion of an item in a shopping list.

## Usage

-  Rename .env.example to .env
-  Run `npm i`
-  Run `npm run start` or `npm start`
