import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping-delete-item',
  templateUrl: './shopping-delete-item.component.html',
  styleUrls: ['./shopping-delete-item.component.css']
})
export class ShoppingDeleteItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
