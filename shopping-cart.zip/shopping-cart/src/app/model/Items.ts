export interface Items {
  _id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
}
